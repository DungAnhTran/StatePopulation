import React, {Component} from 'react';
import './App.css';
import StatePopulation from './components/StatePopulation';

 {/* This is main class*/}

class App  extends Component {

  render()
  {
     return (
        <StatePopulation/>
     );
  }
}
export default App;
