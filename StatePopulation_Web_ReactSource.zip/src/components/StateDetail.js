import React, {Component} from 'react';
import './../App.css';

/** StateDetail
 * This is the child component
 * It is used to keep information of each state
 *
 **/
class StateDetail extends Component {
      constructor() {
          super()
          this.state = {
          data: "data",
          };
      }

      render() {

          const { message } = this.props;
          return (
              <div className="container">
                  <div className="row">
                      <label className="floating-label">Total Population</label>
                      <label className="floating-label-value">  {message.total_String}</label>
                  <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                      <label className="floating-label-header-detail">Male</label>
                      <label className="floating-label-detail-value">{ message.totalMale_String }</label>
                  </div>
                  <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                      <label className="floating-label-header-detail ">Female</label>
                      <label className="floating-label-detail-value">{ message.totalFemale_String }</label>
                  </div>
              </div>
                          
              <div>
            
                    <table >
                        <tbody>
                              <tr className="header-detail">
                                   <td>Age</td>
                                   <td>Male</td>
                                   <td>Female</td>
                                   <td>Total</td>
                              </tr>
             
                              <tr >
                               <td>{this.props.message.below_20 && this.props.message.below_20.age}</td>
                                <td className="header-detail-value">{this.props.message.below_20 && this.props.message.below_20.totalMale_String}</td>
                               <td className="header-detail-value">{this.props.message.below_20 && this.props.message.below_20.totalFemale_String}</td>
                               <td className="header-detail-value">{this.props.message.below_20 && this.props.message.below_20.total_String}</td>
                            </tr>
                            <tr >
                               <td>{this.props.message.between20_40 && this.props.message.between20_40.age}</td>
                                <td className="header-detail-value">{this.props.message.between20_40 && this.props.message.between20_40.totalMale_String}</td>
                               <td className="header-detail-value">{this.props.message.between20_40 && this.props.message.between20_40.totalFemale_String}</td>
                               <td className="header-detail-value">{this.props.message.between20_40 && this.props.message.between20_40.total_String}</td>
                            </tr>
                            <tr >
                              <td>{this.props.message.between40_60 && this.props.message.between40_60.age}</td>
                               <td className="header-detail-value">{this.props.message.between40_60 && this.props.message.between40_60.totalMale_String}</td>
                              <td className="header-detail-value">{this.props.message.between40_60 && this.props.message.between40_60.totalFemale_String}</td>
                              <td className="header-detail-value">{this.props.message.between40_60 && this.props.message.between40_60.total_String}</td>
                            </tr>
                            <tr >
                               <td>{this.props.message.above_60 && this.props.message.above_60.age}</td>
                               <td className="header-detail-value">{this.props.message.above_60 && this.props.message.above_60.totalMale_String}</td>
                               <td className="header-detail-value">{this.props.message.above_60 && this.props.message.above_60.totalFemale_String}</td>
                               <td className="header-detail-value">{this.props.message.above_60 && this.props.message.above_60.total_String}</td>
                            </tr>

                      </tbody>
                  </table>
              </div>

           </div>
          
   
    );
  }
}
export default StateDetail;