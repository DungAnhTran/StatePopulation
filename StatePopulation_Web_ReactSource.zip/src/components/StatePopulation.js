import React, {Component} from 'react';
import axios from 'axios'
import ReactTable from "react-table-6"; 
import 'react-table-6/react-table.css'
import './../App.css';
import StateDetail from './StateDetail';

 /** StatePopulation
 * This is the parent component
 * It is used to keep information of all states
 *
 **/

class StatePopulation extends Component {
	
constructor(props){
    super(props)
    this.state = {
        /**  Data: all states  **/ 
        data: [],
        /**  childData: data of each state to pass to child component  **/ 
        childData:[],
        loading:true,
   
    }
    this.onSubmitMessage = this.onSubmitMessage.bind(this);
  }

 onSubmitMessage(message) {
    this.setState({ message: message });
  }

  instance = axios.create({
  baseURL: "http://localhost:90/",
  withCredentials: false,
  headers: {
    'Access-Control-Allow-Origin' : '*',
    'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE,PATCH,OPTIONS',
    }
})
 /**  Call rest API to get all data from excel file  **/ 
  async getStateData(){
        this.instance()
        const res = await axios.get('http://localhost:90/statepopulation')

        console.log(res.data.states)

        this.setState({loading:false, data: res.data})
        this.setState({loading:false, childData: res.data})
  }

  componentDidMount(){
    this.getStateData()
  }

   /**  Filter state and send to child ccomponent  **/ 
  getStateByName(state) {
       
        let selectedState= this.state.data.states.find(a => a.state === state);
        //                console.log(selectedProduct);
        this.setState({loading:false, childData: selectedState})                 
    }

 
  getTrProps = (state, rowInfo, column) => {
      if (rowInfo) {
          return {
            /**  mouse over to get the selected state detail **/ 
            onMouseEnter: (e) => {
                this.getStateByName(rowInfo.row.state)
            },
            /**  mouse leave to get the all states detail **/ 
            onMouseLeave: (e) => {
                this.setState({loading:false, childData: this.state.data})
            },
            
            style: {
                background:  "#" +
            (function lol(m, s, c) {
               return rowInfo.row.population + (c && lol(m, s, c - 1));
            })(Math, "0123456789ABCDEF", 4),
                color: 'black'
           }
        }
      }
      return {};
  }
 

  render() {
        const { message } = this.state;
        const columns = [{  
              Header: 'Top 10 State',  
              accessor: 'state',
              width: 200,
           
          }
         ,{  
              Header: 'Population',  
              accessor: 'population' ,
               width: 200

          }
          
        ]
    return (
          <div className="container">
          <div className="row">
          <label className="floating-label">Japan</label>
               <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <ReactTable  
                        data={this.state.data.states}  
                        columns={columns}  
                        defaultPageSize = {10}  
                        showPaginationBottom={false}
                        getTrProps={this.getTrProps}
                       />
                  </div>
                  <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                        <StateDetail  message={this.state.childData}/>
                  </div>

               </div>
           </div>         
           
       

    )
  }
}

export default StatePopulation;