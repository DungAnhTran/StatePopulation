﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: StateDetailDTO.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : This class is used to keep information details of each state
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.DTO
{
    public class StateDetailDTO

    {
    

        public string Age
        {
            get;
            set;
        }

        public Int32 Male
        {
            get;
            set;
        }

      
        public Int32 Female
        {
            get;
            set;
        }

     
        public Int32 Total
        {
            get;
            set;
        }

        public String TotalMale_String
        {
            get;
            set;
        }


        public String TotalFemale_String
        {
            get;
            set;
        }


        public String Total_String
        {
            get;
            set;
        }
        //public StateSummaryDTO StateSummary
        // {
        //    get;
        //    set;
        // }

    }
}
