﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: StateDTO.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : This class is used to keep information of 10 states
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.DTO
{
    public class StateDTO
    {
        public string State
        {
            get;
            set;
        }
        public Int32 Population
        {
            get;
            set;
        }

        public Int32 TotalMale
        {
            get; set;

        }
        public Int32 TotalFemale
        {
            get; set;

        }
        public Int32 Total
        {
            get; set;

        }
        public StateDetailDTO Below_20
        {
            get;
            set;
        }

        public StateDetailDTO Between20_40
        {
            get;
            set;
        }

        public StateDetailDTO Between40_60
        {
            get;
            set;
        }

        public StateDetailDTO Above_60
        {
            get;
            set;
        }

        public String Total_String
        {
            get;
            set;
        }

        public String TotalMale_String
        {
            get;
            set;
        }

        public String TotalFemale_String
        {
            get;
            set;
        }

    }
}
