﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PopulationRestAPI.DTO
{
    
    public class CountryDTO
    {
        public Int32 Total
        {
            get;
            set;
        }

        public Int32 TotalMale
        {
            get;
            set;
        }

        public Int32 TotalFemale
        {
            get;
            set;
        }

        public StateDetailDTO Below_20
        {
            get;
            set;
        }

        public StateDetailDTO Between20_40
        {
            get;
            set;
        }

        public StateDetailDTO Between40_60
        {
            get;
            set;
        }

        public StateDetailDTO Above_60
        {
            get;
            set;
        }

        public List<StateDTO> States
        {
            get;
            set;
        }

        public String Total_String
        {
            get;
            set;
        }

        public String TotalMale_String
        {
            get;
            set;
        }

        public String TotalFemale_String
        {
            get;
            set;
        }
    }
}
