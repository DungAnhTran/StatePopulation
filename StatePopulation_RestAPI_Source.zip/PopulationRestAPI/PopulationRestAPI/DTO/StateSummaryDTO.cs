﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PopulationRestAPI.DTO
{
    public class StateSummaryDTO
    {
        public Int32 Total
        {
            get; set;

        }

        public Int32 TotalMale
        {
            get; set;

        }
        public Int32 TotalFemale
        {
            get; set;

        }
    }
}
