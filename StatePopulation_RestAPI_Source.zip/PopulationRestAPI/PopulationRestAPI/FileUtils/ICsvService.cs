﻿using PopulationRestAPI.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: ICsvService.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : Interface to read CSV file
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.FileUtils
{
    public interface ICsvService
    {
        CountryDTO  GetTopTenState(string filePath);
    }
}
