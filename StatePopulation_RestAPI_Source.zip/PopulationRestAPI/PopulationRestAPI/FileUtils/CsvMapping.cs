﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: CsvMapping.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : Mapping file struture to Object
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.FileUtils
{
    public class CsvMapping
    {
        public CsvModel MapToObject(string country, string state, string gender , string age, Int32 totalPopulation)
        {
            CsvModel csvModel = new CsvModel
            {
                Country = country,
                State = state,
                Gender = gender,
                Age = age,
                Total_Population = totalPopulation

            };
            return csvModel;
        }
    }
}
