﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: CSVStructure.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : Create the structure of original csv data
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.FileUtils
{
    public class CsvModel

    {
        public string Country
        {
            get;
            set;
        }
        public string State
        {
            get;
            set;
        }

        public string Gender
        {
            get;
            set;
        }
        public string Age
        {
            get;
            set;
        }
        public Int32 Total_Population
        {
            get;
            set;
        }
    }
}
