﻿using PopulationRestAPI.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: CsvConstructor.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : Constructor Injection
///////////////////////////////////////////////////////////////////////////////////////////////
///
namespace PopulationRestAPI.FileUtils
{
    public class CsvConstructor
    {
        private ICsvService iCsvService;
        public CsvConstructor(ICsvService iCsvService)
        {
            this.iCsvService = iCsvService;
        }
        public CountryDTO GetTopTenState(string filePath)
        {
           return iCsvService.GetTopTenState(filePath);
        }
    }
}
