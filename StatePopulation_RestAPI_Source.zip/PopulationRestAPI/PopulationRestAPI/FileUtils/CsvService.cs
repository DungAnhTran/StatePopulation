﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using PopulationRestAPI.DTO;

/////////////////////////////////////////////////////////////////////////////////////////////////
//FileName: CsvService.cs
//FileType: Visual C# Source file
//Author : Dung Tran
//Created On : 10/Oct/2021 9:56:39 PM
//Last Modified On :
//Copy Rights : 
//Description : Implement ICsvService Interface to read CSV file
///////////////////////////////////////////////////////////////////////////////////////////////
namespace PopulationRestAPI.FileUtils
{
    public class CsvService : ICsvService
    {
        const string BELOW_20 = "Below 20";
        const string BETWEEN_20_40 = "20-40";
        const string BETWEEN_40_60 = "40-60";
        const string ABOVE_60 = "Above 60";
        public CountryDTO GetTopTenState(string filePath)
        {
            List<CsvModel> result= new List<CsvModel>();
            try
            {
                string[] values;
                char[] seperators = { ',' };

                StreamReader sr = new StreamReader(filePath);

                string data = sr.ReadLine();

                while ((data = sr.ReadLine()) != null)
                {
                    values = data.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
                    CsvMapping mapping = new CsvMapping();
                    result.Add(mapping.MapToObject(values[0], values[1], values[2], values[3], Convert.ToInt32(values[4])));
                }


                CountryDTO countryDTO = getCountryInformation(result);
                countryDTO.States =  getTopTenPopulation(result);
                return countryDTO;

                //return getTopTenPopulation(result);
                //;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        /// <summary>This function is used to get Top Ten Population
        ///    
        /// 
        /// </summary>
        private List<StateDTO> getTopTenPopulation(List<CsvModel> listPopulation)
        {

            var listState = listPopulation.GroupBy(t => t.State, (key, t) =>
            {
                var transactionArray = t as CsvModel[] ?? t.ToArray();
                return new StateDTO()
                {
                    State = key,
                    Population = transactionArray.Sum(ta => ta.Total_Population),
                    Below_20 = getStateDetail(listPopulation, key, BELOW_20),
                    Between20_40 = getStateDetail(listPopulation, key, BETWEEN_20_40),
                    Between40_60 = getStateDetail(listPopulation, key, BETWEEN_40_60),
                    Above_60 = getStateDetail(listPopulation, key, ABOVE_60),
                    TotalMale = getStateSummary(listPopulation, key).TotalMale,
                    TotalFemale = getStateSummary(listPopulation, key).TotalFemale,
                    Total = getStateSummary(listPopulation, key).Total,
                    Total_String = ConvertToString(getStateSummary(listPopulation, key).Total),
                    TotalFemale_String = ConvertToString(getStateSummary(listPopulation, key).TotalFemale),
                    TotalMale_String = ConvertToString(getStateSummary(listPopulation, key).TotalMale),

            };
            }).ToList().OrderByDescending(x=>x.Population).Take(10);

           
            return listState.ToList();
        }

        /// <summary>This function is used to get the details of each state
        ///    
        /// 
        /// </summary>
        private StateDetailDTO  getStateDetail (List<CsvModel> listPopulation, string stateName, String age)
        {
            StateDetailDTO stateDetail = new StateDetailDTO();
            var items = listPopulation.FindAll(x => x.State == stateName && x.Age == age);
            if (items !=null && items.Count ==2)
            {
                stateDetail.Age = age;
                stateDetail.Female = items[0].Gender == "Female" ? items[0].Total_Population : items[1].Gender == "Female" ? items[1].Total_Population : 0;
                stateDetail.Male = items[0].Gender == "Male" ? items[0].Total_Population : items[1].Gender == "Male" ? items[1].Total_Population : 0;
                stateDetail.Total = stateDetail.Female + stateDetail.Male;

                stateDetail.Total_String = ConvertToString(stateDetail.Total);
                stateDetail.TotalMale_String = ConvertToString(stateDetail.Male);
                stateDetail.TotalFemale_String = ConvertToString(stateDetail.Female);

            }
            return stateDetail;

        }

      
        /// <summary>This function is used to get the details of each state
        ///    
        /// 
        /// </summary>
        private StateSummaryDTO getStateSummary(List<CsvModel> listPopulation, string stateName)
        {
            StateSummaryDTO listStateDetail = new StateSummaryDTO();
            var items = listPopulation.FindAll(x => x.State == stateName).ToList();
            if (items != null)
            {
               Int32 totalMale = items.FindAll(x => x.Gender == "Male").Sum(y => y.Total_Population);
               Int32 totalFemale = items.FindAll(x => x.Gender == "Female").Sum(y => y.Total_Population);

                listStateDetail.TotalMale = totalMale;
                listStateDetail.TotalFemale = totalFemale;
                listStateDetail.Total = totalMale + totalFemale;

            }
            return listStateDetail;

        }

        private StateDetailDTO getGroudAgeForCountry(List<CsvModel> listPopulation,  String age)
        {
            StateDetailDTO stateDetail = new StateDetailDTO();
            var itemAges = listPopulation.FindAll(x => x.Age == age);
            if (itemAges != null )
            {
                stateDetail.Age = age;
                //var femaleItem = itemAges.FindAll(x => x.Gender == "Female");
                var genderAmmounts = itemAges.GroupBy(t => t.Gender)
                           .Select(t => new
                           {
                               Gender = t.Key,
                               Amount = t.Sum(ta => ta.Total_Population),
                           }).ToList();


                stateDetail.Female = genderAmmounts[0].Gender == "Female" ? genderAmmounts[0].Amount : genderAmmounts[1].Gender == "Female" ? genderAmmounts[1].Amount : 0;
                stateDetail.Male = genderAmmounts[0].Gender == "Male" ? genderAmmounts[0].Amount : genderAmmounts[1].Gender == "Male" ? genderAmmounts[1].Amount : 0;
                stateDetail.Total = stateDetail.Female + stateDetail.Male;
                stateDetail.Total_String = ConvertToString(stateDetail.Total);
                stateDetail.TotalFemale_String = ConvertToString(stateDetail.Female);
                stateDetail.TotalMale_String = ConvertToString(stateDetail.Male);

            }
            return stateDetail;

        }
        private CountryDTO getCountryInformation(List<CsvModel> listPopulation)
        {
            CountryDTO result = new CountryDTO();

            var genderInfor = listPopulation.GroupBy(t => t.Gender)
                           .Select(t => new
                           {
                               Gender = t.Key,
                               Amount = t.Sum(ta => ta.Total_Population),
                           }).ToList();

            if (genderInfor !=null)
            {
                Int32 totalMale = genderInfor.FindAll(x => x.Gender == "Male").FirstOrDefault().Amount;
                Int32 totalFemale = genderInfor.FindAll(x => x.Gender == "Female").FirstOrDefault().Amount;
                result.TotalFemale = totalFemale;
                result.TotalMale = totalMale;
                result.Total = totalFemale + totalMale;

                result.Total_String = ConvertToString(result.Total);
                result.TotalMale_String = ConvertToString(result.TotalMale);
                result.TotalFemale_String = ConvertToString(result.TotalFemale);

                result.Below_20 = getGroudAgeForCountry(listPopulation, BELOW_20);
                result.Between20_40 = getGroudAgeForCountry(listPopulation, BETWEEN_20_40);
                result.Between40_60 = getGroudAgeForCountry(listPopulation, BETWEEN_40_60);
                result.Above_60 = getGroudAgeForCountry(listPopulation, ABOVE_60);
            }
            return result;
        }

        private string ConvertToString(long num)
        {

            // Ensure number has max 3 significant digits (no rounding up can happen)
            long i = (long)Math.Pow(10, (int)Math.Max(0, Math.Log10(num) - 2));
            num = num / i * i;

            if (num >= 1000000000)
                return (num / 1000000000D).ToString("0.##") + "B";
            if (num >= 1000000)
                return (num / 1000000D).ToString("0.##") + "M";
            if (num >= 1000)
                return (num / 1000D).ToString("0.##") + "K";

            return num.ToString("#,0");

            

        }

    }
}
