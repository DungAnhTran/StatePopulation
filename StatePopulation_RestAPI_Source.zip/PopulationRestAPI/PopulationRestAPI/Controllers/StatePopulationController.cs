﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System.Collections.Generic;

using PopulationRestAPI.FileUtils;
using PopulationRestAPI.DTO;


namespace PopulationRestAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StatePopulationController : ControllerBase
    {
       
        private readonly ILogger<StatePopulationController> _logger;

        public StatePopulationController(ILogger<StatePopulationController> logger)
        {
            _logger = logger;
        }


        [HttpGet]
        public CountryDTO Get()
        {

            CsvConstructor cs = new CsvConstructor(new CsvService());
           return cs.GetTopTenState(@"C:\aon\Data for Web Development Test.csv");
         
        }

        
    }
}
